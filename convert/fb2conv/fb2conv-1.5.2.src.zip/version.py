# -*- coding: utf-8 -*- 

VERSION = u'1.5.2'
